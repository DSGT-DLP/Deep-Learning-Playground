SENDER = "DSGT Playground <dsgtplayground@gmail.com>"
AWS_REGION = "us-west-2"
CHARSET = "utf-8"